from setuptools import setup

setup(
    name='paquete',
    version='1.0',
    description='mi primer paquete redis',
    author='Franco',
    packages=['paquete'],


)
